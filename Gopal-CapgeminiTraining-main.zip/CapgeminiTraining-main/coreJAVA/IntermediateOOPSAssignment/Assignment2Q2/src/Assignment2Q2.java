
public class Assignment2Q2 {
 
    
    
    public static void main(String[] args) {
    	
    	Labour l = new Labour();
    	Manager m = new Manager();
    	
    	System.out.println(m.getSalary(m.salary));
    	System.out.println(l.getSalary(l.salary));
    	
    	
    }
}