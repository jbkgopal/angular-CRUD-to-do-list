abstract class DesertItem {
    abstract public int getCost();
}