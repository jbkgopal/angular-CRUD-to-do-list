class bank {
	public int totalDeposits = 10000;
}