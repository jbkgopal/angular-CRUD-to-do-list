
public class IllegalBankTransactionException extends RuntimeException {
	public IllegalBankTransactionException() {
		System.out.println("Illegal Bank Transaction");
	}
}
