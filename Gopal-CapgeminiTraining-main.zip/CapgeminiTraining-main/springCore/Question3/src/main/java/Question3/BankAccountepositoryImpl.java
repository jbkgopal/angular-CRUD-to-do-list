package Question3;

public class BankAccountepositoryImpl implements BankAccountRepository {

	public double getBalance(long accountId) {
		return 0;
	}

	public double updateBalance(long accountId, double newBalance) {
		return 0;
	}

}
