export class adsModel{
    constructor(
        public title:string,
        public name:string,
        public category:string,
        public discription:string
    ){}
}