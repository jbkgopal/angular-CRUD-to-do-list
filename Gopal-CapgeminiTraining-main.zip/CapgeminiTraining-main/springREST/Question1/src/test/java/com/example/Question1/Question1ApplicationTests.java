package com.example.Question1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Question1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
