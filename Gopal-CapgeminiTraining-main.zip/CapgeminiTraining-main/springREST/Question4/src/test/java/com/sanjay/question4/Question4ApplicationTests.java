package com.sanjay.question4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Question4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
