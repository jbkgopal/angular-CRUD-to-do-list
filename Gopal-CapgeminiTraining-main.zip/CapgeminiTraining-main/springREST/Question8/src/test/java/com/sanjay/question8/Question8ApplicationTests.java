package com.sanjay.question8;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Question8ApplicationTests {

	@Test
	void contextLoads() {
	}

}
