package com.sanjay.question6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Question6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
