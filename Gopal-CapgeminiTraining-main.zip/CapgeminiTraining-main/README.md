# CapgeminiTraining
This repo contains all my work which I have gone through in 90days during Capgemini training program.
