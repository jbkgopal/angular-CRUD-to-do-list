public class InsufficientFundsExpcetion extends Exception {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InsufficientFundsExpcetion() {
        System.out.println("Insufficient Funds");
    }
}