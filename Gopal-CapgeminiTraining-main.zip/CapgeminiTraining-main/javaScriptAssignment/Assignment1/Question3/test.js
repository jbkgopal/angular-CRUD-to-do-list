var n = prompt("Enter the Numbe", 5);
if(n%2 === 0)
    document.getElementById("demo").innerHTML = "Even Number";
else
    document.getElementById("demo").innerHTML = "Odd Number";
