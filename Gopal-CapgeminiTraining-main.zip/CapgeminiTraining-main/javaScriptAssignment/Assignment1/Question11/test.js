var fruits = ["Banana", "Orange", "Apple", "Mango"];
console.log(fruits);

function reverseArray(arr){
    return arr.reverse();
}
var arr1 = reverseArray(fruits);
console.log(fruits);