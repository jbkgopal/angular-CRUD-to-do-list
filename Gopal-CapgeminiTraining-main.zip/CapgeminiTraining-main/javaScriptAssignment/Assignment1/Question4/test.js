var n = prompt("Enter the Head Ration", 5);
var a = 567;
function headratio(x){
    document.getElementById('demo').innerHTML = a/x;
}
headratio(n);