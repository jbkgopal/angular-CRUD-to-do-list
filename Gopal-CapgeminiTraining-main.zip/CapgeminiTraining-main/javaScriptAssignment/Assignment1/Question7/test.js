var n = prompt("The the $ value to convert", 100)

console.log("INR "+n/74.28);
console.log("YEN "+n/109.14);
console.log("EURO "+n/0.84);
console.log("POUND "+n/0.72);
