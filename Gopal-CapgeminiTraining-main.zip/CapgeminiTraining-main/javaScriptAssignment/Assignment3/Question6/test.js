var str = ({
    firstName : "Sanjay",
    lastName : "Kumar"
})

var res = eval(str);
console.log(res);

console.log(typeof(str));