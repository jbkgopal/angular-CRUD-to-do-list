var personName = {
    firstName : "",
    lastName : ""
}

personName.firstName = "sanjay";
personName.lastName = "kumar";
console.log(personName.firstName);
console.log(personName.lastName);

//new Question5
console.log(personName.middleName)
personName.middleName = "yadav";
console.log(personName.middleName)