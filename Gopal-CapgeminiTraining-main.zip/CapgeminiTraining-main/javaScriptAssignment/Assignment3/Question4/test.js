// var Rectangle = {
//     height : 100,
//     width: 200
// };

var personName = {
    firstName : "",
    lastName : ""
}

personName.firstName = "sanjay";
personName.lastName = "kumar";
console.log(personName.firstName);
console.log(personName.lastName);