package henry.jewelry.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "`product_table`")
public class Product {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	private String imgURL;

	private String type;

	private String metal;

	private String description;

	private double originalPrice;

	private int discount;

	private double price;

	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Product(int id, String imgURL, String type, String metal, String description, double originalPrice,
			int discount, double price) {
		super();
		this.id = id;
		this.imgURL = imgURL;
		this.type = type;
		this.metal = metal;
		this.description = description;
		this.originalPrice = originalPrice;
		this.discount = discount;
		this.price = price;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getImgURL() {
		return imgURL;
	}

	public void setImgURL(String imgURL) {
		this.imgURL = imgURL;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getMetal() {
		return metal;
	}

	public void setMetal(String metal) {
		this.metal = metal;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getOriginalPrice() {
		return originalPrice;
	}

	public void setOriginalPrice(double originalPrice) {
		this.originalPrice = originalPrice;
	}

	public int getDiscount() {
		return discount;
	}

	public void setDiscount(int discount) {
		this.discount = discount;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", imgURL=" + imgURL + ", type=" + type + ", metal=" + metal + ", description="
				+ description + ", originalPrice=" + originalPrice + ", discount=" + discount + ", price=" + price
				+ "]";
	}

}
