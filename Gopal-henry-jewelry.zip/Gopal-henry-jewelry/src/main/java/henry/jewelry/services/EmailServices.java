package henry.jewelry.services;

public interface EmailServices {

    void sendEmail(String name, String email, String subject, String message);
}
