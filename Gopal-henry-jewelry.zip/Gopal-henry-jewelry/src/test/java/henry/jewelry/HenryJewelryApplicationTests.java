package henry.jewelry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HenryJewelryApplicationTests {

    @Test
    void contextLoads() {
    }

}
